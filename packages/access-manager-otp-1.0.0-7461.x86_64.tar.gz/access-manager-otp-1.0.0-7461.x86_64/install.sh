#!/bin/sh
#
#  This code was developped by SECIOSS, Inc. (https://www.secioss.co.jp/).
#
#  Copyright (C) 2017 SECIOSS, Inc.
#  All rights reserved.
#

PREFIX="/opt/secioss"
LOG="/tmp/install.log"

cat /dev/null >${LOG}

source ./install.rc

if [ -z "${REQUIRE_PACKAGES}" ]; then
	echo "Environment variable 'REQUIRE_PACKAGES' isn't defined." 2>&1
	exit 1
fi

if [ -z "${CONFLICT_PACKAGES}" ]; then
	echo "Environment variable 'CONFLICT_PACKAGES' isn't defined." 2>&1
	exit 1
fi

if [ -z "${THIRD_PARTY_PACKAGES}" ]; then
	echo "Environment variable 'THIRD_PARTY_PACKAGES' isn't defined." 2>&1
	exit 1
fi

if [ -z "${SECIOSS_PACKAGES}" ]; then
	echo "Environment variable 'SECIOSS_PACKAGES' isn't defined." 2>&1
	exit 1
fi

function install() {
	error=
	for package in ${CONFLICT_PACKAGES}; do
		rpm -q ${package} >>$LOG 2>&1
		if [ $? -eq 0 ]; then
			echo "${package}は競合します。アンインストールしてください。"
			error=1
		fi
	done
	
	if [ -n "$error" ]; then
		exit 1;
	fi
	
	if [ -z "${SILENT}"  -a -f LICENSE.txt ]; then
		more LICENSE.txt
		agreed=
		while [ -z "$agreed" ]; do
			echo
			echo "ソフトウェア使用許諾契約書に同意しますか？ [yes/no]"
			read reply leftover
			case $reply in
				[yY] | [yY][eE][sS])
					agreed=1
					;;
				[nN] | [nN][oO])
					echo "ソフトウェア使用許諾契約書に同意できない場合、このソフトウェアをインストールすることはできません。";
					exit 1
					;;
			esac
		done
	fi
	
	error=
	for package in ${REQUIRE_PACKAGES}; do
		rpm -q ${package} >>$LOG 2>&1
		if [ $? -ne 0 ]; then
			echo "${package}が必要です。"
			require=1
		fi
	done
	
	if [ -n "$require" ]; then
		agreed=${SILENT}
		while [ -z "$agreed" ]; do
			echo
			echo "yumリポジトリから必須パッケージをインストールします。よろしいですか？ [yes]"
			read reply leftover
			case $reply in
				'' | [yY] | [yY][eE][sS])
					agreed=1
					;;
				[nN] | [nN][oO])
					echo "必須パッケージのインストールを行ってください。";
					exit 1
					;;
			esac
		done
		
		error=
		for package in ${REQUIRE_PACKAGES}; do
			rpm -q ${package} >>$LOG 2>&1
			if [ $? -ne 0 ]; then
				echo "${package}をインストールしています。"
				yum -y install ${package} >>$LOG 2>&1
				if [ $? -ne 0 ]; then
					echo "${package}のインストールに失敗しました。"
					error=1
				else
					echo "${package}のインストールに成功しました。"
				fi
			fi
		done
		
		if [ -n "$error" ]; then
			echo "必須パッケージのインストールに失敗しました。"
			exit 1;
		fi
	fi
	
	for package in ${THIRD_PARTY_PACKAGES}; do
		# 依存パッケージの存在確認
		THIRD_PARTY_DEPENDENCY=`echo ${package^^} | sed -e s/-/_/g`
		DEPENDENCY_PACKAGES="$(eval echo '$'${THIRD_PARTY_DEPENDENCY})"
		DEPENDENCES=
		if [ ! -z "${DEPENDENCY_PACKAGES}" ]; then
			# 依存関係パッケージのパス作成
			for dependency in $DEPENDENCY_PACKAGES;
			do
				# 依存パッケージ追加
				DEPENDENCES="${DEPENDENCES} ./third_party/${dependency}-[0-9]*.rpm"
			done
		fi
		# インストール
		yum -y localinstall ./third_party/${package}-[0-9]*.rpm ${DEPENDENCES}>>$LOG 2>&1
		if [ $? -ne 0 ]; then
			echo "${package}のインストールに失敗しました。"
			return 1
		fi
		echo "${package}をインストールしました。"
	done
	echo "${PRODUCT}に必要なパッケージをインストールしました。"

	uninstall_package=
	for package in ${SECIOSS_PACKAGES}; do
		yum -y localinstall ./software/${package}-[0-9]*.rpm >>$LOG 2>&1
		if [ $? -ne 0 ]; then
			echo "${package}のインストールに失敗しました。"
			if [ -n "${uninstall_package}" ]; then
				for f in ${uninstall_package}; do
					yum -y erase ${f} >>$LOG 2>&1
					echo "${f}をアンインストールしました。"
				done
			fi
			return 1
		fi
		echo "${package}をインストールしました。"
		uninstall_package="${package} ${uninstall_package}"
	done

	for file in ${GARBAGE_FILES}; do
		rm -rf $file >>$LOG 2>&1
	done

	if [ -z "${SILENT}" ]; then
		if [ -e 'setup.pl' ]; then
			answer=
			while [ -z "$answer" ]; do
				echo
				echo "引き続き初期設定ツールを起動します。よろしいですか？ [yes]"
				read reply leftover
				case $reply in
					'' | [yY] | [yY][eE][sS])
						answer=1
						./setup.pl
						;;
					[nN] | [nN][oO])
						answer=1
						;;
				esac
			done

			echo "後で設定を変更するには setup.pl コマンドを実行してください。"
		fi
	fi
	
	return 0
}

function update() {
	error=
	for package in ${CONFLICT_PACKAGES}; do
		rpm -q ${package} >>$LOG 2>&1
		if [ $? -eq 0 ]; then
			echo "${package}は競合します。アンインストールしてください。"
			error=1
		fi
	done
	
	for package in ${REQUIRE_PACKAGES}; do
		rpm -q ${package} >>$LOG 2>&1
		if [ $? -ne 0 ]; then
			echo "${package}が必要です。インストールしてください。"
			error=1
		fi
	done
	
	if [ -n "$error" ]; then
		exit 1;
	fi
	
	for package in ${THIRD_PARTY_PACKAGES}; do
			rpm -Uvh --replacepkgs ./third_party/${package}-[0-9]*.rpm >>$LOG 2>&1
			if [ $? -ne 0 ]; then
					# 依存パッケージの存在確認
					THIRD_PARTY_DEPENDENCY=`echo ${package^^} | sed -e s/-/_/g`
					DEPENDENCY_PACKAGES="$(eval echo '$'${THIRD_PARTY_DEPENDENCY})"
					DEPENDENCES=
					if [ ! -z "${DEPENDENCY_PACKAGES}" ]; then
							# 依存関係パッケージのパス作成
							for dependency in $DEPENDENCY_PACKAGES;
							do
									# 依存パッケージ追加
									DEPENDENCES="${DEPENDENCES} ./third_party/${dependency}-[0-9]*.rpm"
							done
					fi
					yum -y localinstall ./third_party/${package}-[0-9]*.rpm ${DEPENDENCES}>>$LOG 2>&1
					if [ $? -ne 0 ]; then
							echo "${package}のアップデートに失敗しました。"
							return 1
					fi
					yum -y localupdate ./third_party/${package}-[0-9]*.rpm ${DEPENDENCES}>>$LOG 2>&1
					if [ $? -ne 0 ]; then
							echo "${package}のアップデートに失敗しました。"
							return 1
					fi
			fi
			echo "${package}をアップデートしました。"
	done

	for package in ${SECIOSS_PACKAGES}; do
		rpm -Uvh --replacepkgs ./software/${package}-[0-9]*.*.rpm >>$LOG 2>&1
		if [ $? -ne 0 ]; then
			yum -y localinstall ./software/${package}-[0-9]*.*.rpm >>$LOG 2>&1
			if [ $? -ne 0 ]; then
				echo "${package}のアップデートに失敗しました。"
				return 1
			fi
			yum -y localupdate ./software/${package}-[0-9]*.*.rpm >>$LOG 2>&1
			if [ $? -ne 0 ]; then
				echo "${package}のアップデートに失敗しました。"
				return 1
			fi
		fi
		echo "${package}をアップデートしました。"
	done

	if [ -e 'setup.pl' ]; then
		echo "設定の復元を行っています。"
		./setup.pl -r
		if [ $? -ne 0 ]; then
			echo "設定の復元に失敗しました。 setup.pl コマンドを実行して個別に設定を復元して下さい。"
			return 1
		fi
	fi

	return 0
}

function uninstall() {
	REV_SECIOSS_PACKAGES=
	for package in ${SECIOSS_PACKAGES}; do
		REV_SECIOSS_PACKAGES="${package} ${REV_SECIOSS_PACKAGES}"
	done
	
	if [ -z "${SILENT}" ]; then
		agreed=
		while [ -z "$agreed" ]; do
			echo
			echo "本当にアンインストールしてもよろしいですか？ [yes/no]"
			read reply leftover
			case $reply in
				[yY] | [yY][eE][sS])
					agreed=1
					;;
				[nN] | [nN][oO])
					exit 1
					;;
			esac
		done
	fi
	
	for package in ${REV_SECIOSS_PACKAGES}; do
		yum -y erase ${package} >>$LOG 2>&1
		if [ $? -ne 0 ]; then
			echo "${package}のアンインストールに失敗しました。"
		else
			echo "${package}をアンインストールしました。"
		fi
	done
}

if [ "$2" = "-y" ]; then
	SILENT=yes
fi

case "$1" in
	install)
		install
		error=$?
		if [ $error -eq 0 ]; then
			echo "${PRODUCT}のインストールが完了しました。"
		else
			echo "${PRODUCT}のインストールに失敗しました。" 1>&2
			exit 1
		fi
		;;
	update)
		update
		error=$?
		if [ $error -eq 0 ]; then
			echo "${PRODUCT}のアップデートが完了しました。"
		else
			echo "${PRODUCT}のアップデートに失敗しました。" 1>&2
			exit 1
		fi
		;;
	uninstall)
		uninstall
		echo "${PRODUCT}のアンインストールが完了しました。"
		;;
	*)
		echo $"Usage: $0 {install|update|uninstall}"
		exit 1
esac

